#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""P1AY release check. Run in the unpacked release folder:  python3 P1AY_CHECK.py
Needs only Python 3.8+. Changes nothing. Exit code 0 = OK, 1 = problems found.
Checks: manifest hashes; JSON validity; no .md files; CORE is one file with every rule in full (no stubs);
unique rule ids; references between rules; the language layer; no personal identifiers."""
import hashlib, json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
SYS = os.path.join(HERE, "system")
SECTIONS = ("required_rules", "runtime_protocol", "operational_additions", "restored_rules")
problems, notes = [], []


def bad(msg):
    problems.append(msg)


def read(rel):
    with open(os.path.join(HERE, rel), encoding="utf-8") as f:
        return json.load(f)


def sha(p):
    with open(p, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def name_of(e):
    return e.get("id") or e.get("title")


def main():
    try:
        man = read("RELEASE_MANIFEST.json")
    except Exception as e:
        bad("RELEASE_MANIFEST.json unreadable: %s" % e)
        man = {"files": []}
    listed = set()
    for it in man.get("files", []):
        p = os.path.join(HERE, it["path"])
        listed.add(it["path"])
        if not os.path.isfile(p):
            bad("manifest: missing file " + it["path"])
        elif sha(p) != it["sha256"] or os.path.getsize(p) != it["bytes"]:
            bad("manifest: hash or size differs for " + it["path"] + " (rebuild the manifest after an intended change)")
    docs = {}
    for root, dirs, files in os.walk(HERE):
        dirs[:] = [d for d in dirs if d not in (".git", "__pycache__")]
        for fn in files:
            rel = os.path.relpath(os.path.join(root, fn), HERE).replace(os.sep, "/")
            if fn.lower().endswith(".md"):
                bad("no .md files in the release: " + rel)
            if fn.endswith(".json"):
                try:
                    docs[rel] = read(rel)
                except Exception as e:
                    bad("invalid JSON: %s (%s)" % (rel, e))
            if rel.startswith("system/") and rel not in listed:
                bad("file not in RELEASE_MANIFEST.json: " + rel)
    core = docs.get("system/P1AY_CORE.json")
    if not core:
        bad("system/P1AY_CORE.json missing or invalid")
        return man
    # CORE: one file, every rule in full
    ids = []
    for sec in SECTIONS:
        lst = core.get(sec)
        if not isinstance(lst, list) or not lst:
            bad("CORE: section missing or empty: " + sec)
            continue
        for i, e in enumerate(lst):
            n = name_of(e) if isinstance(e, dict) else None
            if not n:
                bad("CORE: %s[%d] has no id or title" % (sec, i))
                continue
            ids.append(n)
            if "full" in e or "summary" in e:
                bad("CORE: %s is a stub (has 'full' or 'summary'); every rule must be written in full" % n)
            if not isinstance(e.get("text"), str) or len(e["text"].strip()) < 20:
                bad("CORE: %s has no rule text" % n)
            extra = set(e) - {"id", "title", "text"}
            if extra:
                notes.append("CORE: %s has extra fields: %s" % (n, ", ".join(sorted(extra))))
    for n in sorted(set(i for i in ids if ids.count(i) > 1)):
        bad("CORE: duplicate rule id: " + n)
    known = set(ids)
    for old, new in ((core.get("id_map") or {}).get("items") or {}).items():
        if new not in known:
            bad("CORE: id_map sends %s to an unknown rule %s" % (old, new))
        if old in known:
            bad("CORE: id_map lists %s but the rule still exists" % old)
    for it in (core.get("architecture_foundation") or {}).get("items", []):
        parts = it.split(" ", 2)
        n = re.sub(r"\s*\[[^\]]*\]$", "", parts[2]) if len(parts) == 3 else it
        if n not in known:
            bad("CORE: architecture_foundation item is not a rule: " + n)
    text = " ".join(e["text"] for sec in SECTIONS for e in core.get(sec, []) if isinstance(e, dict) and isinstance(e.get("text"), str))
    for m in sorted(set(re.findall(r"\b[A-Z][A-Z_]+(?:\.[A-Z0-9_]+)*\.\d{3}\b", text))):
        if m not in known and not m.startswith("COMMANDS."):
            notes.append("CORE: a rule mentions an id that is not a rule: " + m)
    for pat, lab in ((r"CORE_RULES_\d|CORE_ARCHIVE_\d|COMM_00\d", "a reference to a file outside CORE"),):
        if re.search(pat, json.dumps(core, ensure_ascii=False)):
            bad("CORE: contains " + lab)
    if os.path.isdir(os.path.join(SYS, "CONTEXT")):
        bad("system/CONTEXT must not exist: CORE is one file")
    mech = (core.get("mechanisms") or {}).get("items") or []
    if len(mech) != 77:
        bad("CORE: mechanisms registry must hold 77 items, found %d" % len(mech))
    for e in mech:
        if not (isinstance(e, dict) and e.get("id") and e.get("definition")):
            bad("CORE: mechanism without id or definition: %s" % str(e)[:40]); break
    _ids = {name_of(e) for s in SECTIONS for e in (core.get(s) or []) if isinstance(e, dict)}
    for rel in sorted(docs):
        if re.match(r"system/P1AY_CORE_[A-Z]{2,3}\.json$", rel):
            im = (docs[rel].get("id_map") or {}).get("translations_removed") or {}
            for old, new in (im.items() if isinstance(im, dict) else []):
                if new not in _ids:
                    bad("%s: id_map %s -> %s is not a CORE rule" % (rel, old, new))
    # language layers
    for rel in sorted(docs):
        m = re.match(r"system/P1AY_CORE_([A-Z]{2,3})\.json$", rel)
        if not m:
            continue
        layer = docs[rel]
        if layer.get("extends") != "P1AY_CORE.json":
            bad(rel + ": extends must be P1AY_CORE.json")
        seen = set()
        for key, v in layer.items():
            if not isinstance(v, list):
                continue
            for e in v:
                if not isinstance(e, dict):
                    continue
                n = name_of(e)
                if "full" in e or "summary" in e:
                    bad("%s: %s is a stub" % (rel, n))
                if not isinstance(e.get("text"), str) or not e["text"].strip():
                    bad("%s: %s has no text" % (rel, n))
                if n in seen:
                    bad("%s: duplicate id %s" % (rel, n))
                seen.add(n)
    # personal identifiers
    for rel in ("system/P1AY_CORE.json",) + tuple(r for r in docs if re.match(r"system/P1AY_CORE_[A-Z]{2,3}\.json$", r)):
        if docs[rel].get("owner_id") != "UNIVERSAL":
            bad(rel + ": owner_id must be UNIVERSAL in a release")
    pats = [(r"[\w.+-]+@[\w-]+\.[a-z]{2,}", "e-mail address"), (r"(?:drive|docs)\.google\.com", "Google Drive link"),
            (r"\"drive_file_id\":\s*\"[^\"]+\"", "Drive file id"), (r"\+\d{10,14}\b", "phone number")]
    for root, dirs, files in os.walk(SYS):
        dirs[:] = [d for d in dirs if d != "__pycache__"]
        for fn in files:
            if not fn.endswith((".json", ".html", ".py", ".js")):
                continue
            rel = os.path.relpath(os.path.join(root, fn), HERE).replace(os.sep, "/")
            with open(os.path.join(root, fn), encoding="utf-8", errors="ignore") as f:
                t = f.read()
            for pat, lab in pats:
                if re.search(pat, t):
                    bad("%s: contains %s" % (rel, lab))
    return man


if __name__ == "__main__":
    man = main()
    for n in notes:
        print("note: " + n)
    for p in problems:
        print("PROBLEM: " + p)
    print("%s: %d problem(s), %d note(s)" % ((man or {}).get("release", "P1AY release"), len(problems), len(notes)))
    print("RESULT: " + ("OK" if not problems else "FAILED"))
    sys.exit(1 if problems else 0)
