#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
P1AY · VALENTINA · 1.1 — ПЕРВЫЙ ЗАПУСК

Запускать ПЕРВЫМ. Нужен только Python 3.8+ (больше ничего ставить не надо).

    python3 P1AY_FIRST_RUN.py                    чистая установка рядом с этим файлом
    python3 P1AY_FIRST_RUN.py --target ПАПКА     обновить уже существующую папку P1AY
    python3 P1AY_FIRST_RUN.py --dry-run          только показать, что будет сделано
    python3 P1AY_FIRST_RUN.py --restore ПАПКА_АРХИВА   вернуть файлы из Archive на место

Синхронизация через Google Drive. ОСНОВНОЙ МАСТЕР выбирается при установке (по умолчанию Claude) и
— единственный писатель мастеров.
Все устройства (компьютер, телефон) и остальные клиенты (ChatGPT, Codex, другие AI) — КЛИЕНТЫ:
читают, проверяют и кладут файлы в TEMP. Первый запуск — это установка/обновление, его делает владелец;
дальше мастера правит только выбранный мастер.
    --sync-status            мастер, совпадают ли файлы с указателем, конфликты Drive, очередь TEMP
    --sync-check             то же, но код выхода 1 при проблемах
    --deliver ФАЙЛ           положить файл в TEMP для мастера
    --master ИМЯ             при установке: какой AI мастер (по умолчанию Claude); если мастер уже есть - сохраняется
    --device-name ИМЯ        имя этого устройства (для имён файлов в TEMP)
    --link-module ПАПКА      подключить модуль (STATE NAVIGATOR, DIGITAL TWIN): папка модуля со своим pointer; записывается в указатель
    --module ИМЯ             имя модуля для --link-module (по умолчанию из имени папки)
    --zip-out ФАЙЛ           после установки упаковать результат в один zip (для ИИ в песочнице)

Что делает:
  1. проверяет целостность релиза;
  2. делает бэкап всего, что уже есть;
  3. строит новую файловую систему: CORE (один файл, все правила целиком), язык, USER, COMMUNICATION, CONTEXT, указатель;
  4. если аккаунт уже был — переносит историю (старые файлы) в CONTEXT без потерь;
     если установка первая — начинает с чистого листа;
  5. применяет обновления (CORE/язык обновляются, если в релизе версия новее);
  6. проверяет всё чтением и выдаёт отчёт;
  7. предлагает перенести старые файлы в Archive. Файлы ПЕРЕНОСЯТСЯ, а не удаляются,
     лежат там до востребования, новая система используется всеми.

Скрипт ничего не удаляет.
"""
import argparse, datetime, hashlib, json, os, platform, re, shutil, socket, sys, zipfile

VERSION = "P1AY · VALENTINA · 1.1"
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.join(HERE, "system")
PART_LIMIT = 4_000_000
IMPORT_LIMIT = 30_000_000
TEXT_EXT = {".md", ".txt", ".json", ".csv", ".tsv", ".html", ".htm", ".yaml", ".yml", ".log", ".xml"}
JUNK = {".DS_Store", "Thumbs.db", "desktop.ini"}
IGNORE_TOP = {"Archive", "P1AY_BACKUP", "P1AY_DASHBOARD", "system", "TEMP", "__pycache__", ".git"}
OWN_FILES = {"P1AY_FIRST_RUN.py", "P1AY_FIRST_RUN_REPORT.txt", "RELEASE_MANIFEST.json", "P1AY_START_HERE.json", "P1AY_CHECK.py", "P1AY_ONBOARDING.html"}
# части мастера CORE по запросу (D116, D117): полные тексты правил, журнал решений
CORE_PART_RE = re.compile(r"P1AY_CORE(_[A-Z]{2,3})?_(RULES|ARCHIVE)_\d+\.json$")
# служебные файлы установки, которые не являются старыми источниками и не переносятся в CONTEXT
AUX_RE = re.compile(r"P1AY_(POINTER_LOG|USER_DETAIL)_\d+\.json$|P1AY_SOURCE_.+\.json$")
USER_SCHEMA = "P1AY_USER_JSON_02"
COMM_SCHEMA = "P1AY_COMMUNICATION_STYLE_01"


def now():
    return datetime.datetime.now().astimezone().replace(microsecond=0)


def sha_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for ch in iter(lambda: f.read(1 << 20), b""):
            h.update(ch)
    return h.hexdigest()


def dumps(o, nl=False):
    return json.dumps(o, ensure_ascii=False, indent=2) + ("\n" if nl else "")


def write_text(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)
    os.replace(tmp, path)


def read_json(p):
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


OLD_COMM_BRIEF = [
    "Short and to the point; no invention, no repeated pressure. Never cut a fully requested result.",
]


def new_local_id():
    import secrets
    return "U" + secrets.token_hex(4).upper()


def rev_num(r):
    m = re.match(r"r(\d+)$", str(r or ""))
    return int(m.group(1)) if m else -1


class Report:
    def __init__(self):
        self.lines = []

    def say(self, t=""):
        print(t)
        self.lines.append(t)

    def head(self, t):
        self.say("")
        self.say("== " + t + " ==")


def ask(q, default=None):
    if not sys.stdin.isatty():
        return default
    try:
        a = input(q).strip()
    except EOFError:
        return default
    return a or default


def is_yes(a):
    return str(a or "").strip().lower() in ("да", "д", "y", "yes", "1")


class Archive:
    """Перенос старых файлов в Archive/<пакет>/ с манифестом. Ничего не удаляет."""

    def __init__(self, target, ts):
        self.target = target
        self.batch = "P1AY_ARCHIVE_" + ts
        self.dir = os.path.join(target, "Archive", self.batch)
        self.items = []

    def move(self, rel, reason, record=None):
        src = os.path.join(self.target, rel)
        dst = os.path.join(self.dir, rel)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        h, b = sha_file(src), os.path.getsize(src)
        shutil.move(src, dst)
        self.items.append({"from": rel, "to": os.path.relpath(dst, self.target), "sha256": h,
                           "bytes": b, "reason": reason, "imported_to_context": record})

    def finalize(self):
        if not self.items:
            return None
        man = {"batch": self.batch, "created_at": now().isoformat(), "created_by": VERSION,
               "note": "Архив-история. Не является источником правил. Файлы перенесены, не удалены.",
               "restore": "python3 P1AY_FIRST_RUN.py --target <папка P1AY> --restore " + self.batch,
               "items": self.items}
        write_text(os.path.join(self.dir, "ARCHIVE_MANIFEST.json"), dumps(man))
        return self.dir


def classify(p, fn):
    if fn == "P1AY_CURRENT_POINTER.json":
        return "pointer", None
    if CORE_PART_RE.match(fn):
        d = read_json(p)
        return "core_part", {"revision": (d or {}).get("revision")}
    if AUX_RE.match(fn):
        return "aux", None
    if fn.lower().endswith(".json"):
        d = read_json(p)
        if isinstance(d, dict):
            t = d.get("document_type")
            meta = {"revision": d.get("revision"), "schema": d.get("schema_version"),
                    "owner_id": d.get("owner_id"), "language": d.get("language"),
                    "part": d.get("part"), "start": d.get("record_start"),
                    "end": d.get("record_end_exclusive")}
            if t == "CORE" and fn == "P1AY_CORE.json":
                return "core", meta
            if t == "CORE_LANGUAGE_LAYER" and re.match(r"P1AY_CORE_[A-Za-z]+\.json$", fn):
                return "lang", meta
            if t == "USER" and fn.startswith("P1AY_"):
                return ("user" if meta["schema"] == USER_SCHEMA else "user_old"), meta
            if t == "COMMUNICATION" and fn == "P1AY_COMMUNICATION.json":
                return ("comm" if meta["schema"] == COMM_SCHEMA else "comm_old"), meta
            if t == "CONTEXT" and re.match(r"P1AY_CONTEXT_\d+\.json$", fn):
                return "context", meta
    return "legacy", None


def scan(target):
    st = {"core": None, "lang": {}, "user": {}, "user_old": {}, "comm": None, "comm_old": None,
          "context": [], "pointer": None, "legacy": [], "junk": [], "temp": [], "core_parts": {}, "aux": []}
    for root, dirs, files in os.walk(target):
        rel_root = os.path.relpath(root, target)
        if rel_root == ".":
            dirs[:] = [d for d in dirs if d not in IGNORE_TOP]
        else:
            dirs[:] = [d for d in dirs if d not in ("__pycache__", ".git")]
        for fn in files:
            p = os.path.join(root, fn)
            rel = os.path.normpath(os.path.relpath(p, target))
            if fn in JUNK or fn.startswith("._") or fn.endswith(".tmp"):
                st["junk"].append(rel)
                continue
            if rel in OWN_FILES or (fn.startswith("P1AY_VALENTINA_") and fn.endswith(".zip")):
                continue
            kind, meta = classify(p, fn)
            if kind == "pointer":
                st["pointer"] = rel
            elif kind == "core":
                st["core"] = (rel, meta)
            elif kind == "lang":
                st["lang"][fn] = (rel, meta)
            elif kind in ("user", "user_old"):
                st[kind][fn] = (rel, meta)
            elif kind == "comm":
                st["comm"] = (rel, meta)
            elif kind == "comm_old":
                st["comm_old"] = (rel, meta)
            elif kind == "context":
                st["context"].append((rel, meta))
            elif kind == "core_part":
                st["core_parts"][fn] = (rel, meta)
            elif kind == "aux":
                st["aux"].append(rel)
            else:
                st["legacy"].append(rel)
    tdir = os.path.join(target, "TEMP")
    if os.path.isdir(tdir):
        for fn in sorted(os.listdir(tdir)):
            if fn not in JUNK and not fn.startswith("._"):
                st["temp"].append(fn)
    st["context"].sort(key=lambda x: x[0])
    return st


def verify_package(rep):
    m = read_json(os.path.join(HERE, "RELEASE_MANIFEST.json"))
    if not m:
        rep.say("ОШИБКА: рядом нет RELEASE_MANIFEST.json. Распакуй архив целиком.")
        return None
    bad = [it["path"] for it in m["files"]
           if not os.path.isfile(os.path.join(HERE, it["path"])) or sha_file(os.path.join(HERE, it["path"])) != it["sha256"]]
    if bad:
        rep.say("ОШИБКА: релиз повреждён, не совпадают файлы: " + ", ".join(bad))
        return None
    rep.say("Целостность релиза: OK (%d файлов, sha256)" % len(m["files"]))
    return m


def detect_user_id(st):
    for rel in st["legacy"]:
        m = re.match(r"P1AY_([A-Za-z0-9]{3,32})\.(md|json|txt)$", os.path.basename(rel))
        if m and m.group(1).upper() not in ("CORE", "COMMUNICATION", "CONTEXT", "SYNC", "BACKUP", "CURRENT"):
            return m.group(1)
    return None


def import_sources(target, paths, known, next_index, ts_iso):
    """Старые файлы -> записи CONTEXT. Без потерь: текст целиком, бинарные - только ссылкой с sha256."""
    recs, imported = [], {}
    idx = next_index
    for rel in paths:
        p = os.path.join(target, rel)
        h, size = sha_file(p), os.path.getsize(p)
        if h in known:
            imported[rel] = known[h]["record_id"]
            continue
        rid = "COMM_%06d" % idx
        text = None
        if os.path.splitext(rel)[1].lower() in TEXT_EXT and size <= IMPORT_LIMIT:
            try:
                with open(p, "rb") as f:
                    text = f.read().decode("utf-8")
            except UnicodeDecodeError:
                text = None
        rec = {"record_id": rid, "kind": "LEGACY_SOURCE" if text is not None else "LEGACY_BINARY_REF",
               "title": rel, "level": 1, "source_file": rel, "imported_at": ts_iso,
               "source_body_sha256": h, "clean_body_sha256": h, "bytes": size}
        rec["content"] = [text] if text is not None else []
        if text is None:
            rec["note"] = "Файл не текстовый или слишком большой: в CONTEXT только ссылка и sha256; сам файл лежит в Archive."
        recs.append(rec)
        imported[rel] = rid
        known[h] = {"record_id": rid, "file": rel}
        idx += 1
    return recs, imported


def slug(s):
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")[:80] or "source"


def write_context_parts(target, template, existing, recs, uid, ts_iso, lang=None):
    """Новые записи кладутся в НОВЫЕ части после существующих; существующие не трогаются."""
    parts = [{"file": os.path.basename(r), "record_start": m["start"], "record_end_exclusive": m["end"]}
             for r, m in existing]
    start = parts[-1]["record_end_exclusive"] if parts else 0
    next_part = (max([m["part"] or 0 for _, m in existing]) + 1) if existing else 1
    chunks, cur, size = [], [], 0
    for r in recs:
        s = len(json.dumps(r, ensure_ascii=False))
        if cur and size + s > PART_LIMIT:
            chunks.append(cur); cur, size = [], 0
        cur.append(r); size += s
    if cur or not existing:
        chunks.append(cur)
    written = []
    for ch in chunks:
        fn = "P1AY_CONTEXT_%03d.json" % next_part
        end = start + len(ch)
        parts.append({"file": fn, "record_start": start, "record_end_exclusive": end})
        written.append((fn, next_part, start, end, ch))
        start, next_part = end, next_part + 1
    out = []
    for fn, part, s, e, ch in written:
        d = json.loads(json.dumps(template))
        d.update({"owner_id": uid, "revision": "r1", "date": ts_iso[:10], "part": part, "language": lang or d.get("language"),
                  "parts": parts, "record_start": s, "record_end_exclusive": e, "record_count": len(ch),
                  "records": ch, "updated_at": ts_iso,
                  "anchor_index": {slug(r["title"]) + "-" + r["record_id"].lower(): part for r in ch}})
        path = os.path.join(target, "CONTEXT", fn)
        write_text(path, dumps(d))
        out.append(os.path.join("CONTEXT", fn))
    return out


POINTER_RULES = [
    "Five canonical JSON masters: P1AY_CORE.json, P1AY_CORE_<LANG>.json, P1AY_<USER_ID>.json, P1AY_COMMUNICATION.json, P1AY_CONTEXT_<NNN>.json (one logical file in parts, on demand).",
    "CORE is one file: every rule is written in P1AY_CORE.json in full and is always loaded; no rule text lives in another file. The language layer holds wording only.",
    "Load by PATH and name (pointer.load_by_path, POINTER.PATH_LOAD.001). Drive IDs are fallback only; revisions and hashes are informational. Never select a file by search.",
    "All canonical files are JSON (UTF-8, ensure_ascii=False), edited in place; names do not change.",
    "Sole master writer: the master named in pointer.sync.master (default Claude). Every other client delivers changes to TEMP/ only (SYNC.AUTHORITY.001).",
    "TEMP = queue of unapplied changes with status MERGED / ALREADY_PRESENT / NO_DELTA / CONFLICT / PENDING.",
    "Backup -> write -> read-back -> restore if needed (BACKUP.RESTORE.002). Backups: P1AY_BACKUP/P1AY_BACKUP_YYYY-MM-DD.zip.",
    "Archive/ is history with ARCHIVE_MANIFEST.json per batch; never input or authority. Old files are moved there, never deleted.",
    "Load tiers: load=always kernel, load=on_demand on request.",
    "RULE NUMBER ONE: always look in CORE. Mandatory CORE.CONFORMANCE.GATE.001: load and apply current CORE kernel and language layer before every task; check the prepared result against all applicable CORE rules immediately before output/action. CORE PREFLIGHT -> TASK -> CORE POSTFLIGHT -> WRITE-CONVERGENCE -> OUTPUT. WRITE-CONVERGENCE: after the final check, if more than 2 items still need entry in the five canonical files, repeat the check and write them until a pass finds 2 or fewer (CORE D38).",
    "Project = separate folder/contour with its own CORE (grows into the five layers only if needed); no one-file-per-project (D23).",
    "TEMP flow: a client writes TEMP/TEMP_<client>_<date>_<name>.json; the master applies it to the masters, records the result in pointer.temp_merge (MERGED / ALREADY_PRESENT / NO_DELTA / CONFLICT / PENDING) and moves the processed file to P1AY_BACKUP/TEMP_PROCESSED_<date>/. TEMP is left empty or holds only pending files.",
    "Drive-only write (D57): masters, TEMP and the pointer are written only inside the synced Google Drive folder and read back from there. A copy saved only locally is a sync failure, not a save.",
    "Sync rules (SYNC.GDRIVE.001, SYNC.MASTER.001, SYNC.MASTER_CHANGE.001, SYNC.CONFLICT.001): the single copy is pointer.sync.rules.",
]

SYNC_RULES = [
    "SYNC.GDRIVE.001: transport is Google Drive for Desktop. The P1AY folder is the same folder on every device; Drive only moves files and does not decide who is right. The pointer, not the Drive timestamp, names the current state.",
    "SYNC.MASTER.001: the main master is the AI named in pointer.sync.master, the sole master writer (chosen at install, default Claude; not a device). Where this CORE says 'Claude' as master writer, read that master. Every device (computer, phone) and every other client (any other AI) is a CLIENT: it reads, verifies and delivers files to TEMP only. The master writes masters, the pointer, backups and Archive and reads them back from Drive before reporting.",
    "SYNC.MASTER_CHANGE.001: the main master is chosen at install and afterwards changed only by an explicit owner decision recorded as a CORE decision; never by a client or a script run on a device.",
    "SYNC.CONFLICT.001: Drive conflict copies (name with (1), 'conflicted copy', 'Copy of', 'Копия') and any local master whose sha256 differs from the pointer manifest are conflicts: nothing is merged silently; the master writer resolves them against the manifest and the backup.",
]
CONFLICT_RE = re.compile(r"(\(\d+\)|conflicted copy|Copy of |Копия| - Copy|_replaced)", re.I)


def device_name(name=None):
    return re.sub(r"[^A-Za-z0-9_-]+", "", name or socket.gethostname() or "device")[:24] or "device"


def drive_info(target):
    p = target.replace("\\", "/") + "/"
    inside = bool(re.search(r"/(GoogleDrive-[^/]+|Google Drive)/", p) or "/My Drive/" in p
                  or re.match(r"^[A-Za-z]:/(My Drive|Google Drive)/", p))
    return {"inside_drive": inside}


def drive_conflicts(target):
    out = []
    for root, dirs, files in os.walk(target):
        rel = os.path.relpath(root, target)
        if rel == ".":
            dirs[:] = [d for d in dirs if d not in ("Archive", "P1AY_BACKUP", "system", "TEMP", "__pycache__")]
        for fn in files:
            if fn.startswith("P1AY_") and CONFLICT_RE.search(fn) and not fn.startswith("P1AY_VALENTINA_"):
                out.append(os.path.normpath(os.path.join(rel, fn)))
    return out


def local_vs_manifest(target, ptr):
    res = []
    for m in (ptr or {}).get("master_manifest", []):
        nm = m.get("name") or os.path.basename(m.get("path", ""))
        rel = m.get("path")
        if not rel:
            rel = nm if os.path.isfile(os.path.join(target, nm)) else os.path.join("CONTEXT", nm)
        m = dict(m, name=nm)
        p = os.path.join(target, rel)
        if not os.path.isfile(p):
            res.append((m["name"], "НЕТ ФАЙЛА (Drive ещё не докачал?)"))
        elif sha_file(p) != m["sha256"]:
            res.append((m["name"], "ОТЛИЧАЕТСЯ от указателя"))
        else:
            res.append((m["name"], "OK"))
    return res


def link_module(target, folder, rep, name=None, dry=False):
    rep.head("ПОДКЛЮЧЕНИЕ МОДУЛЯ")
    pp = os.path.join(target, "P1AY_CURRENT_POINTER.json")
    ptr = read_json(pp)
    if not ptr:
        rep.say("Указатель не найден: сначала установи систему (python3 P1AY_FIRST_RUN.py).")
        return 2
    cands = [folder, os.path.join(target, folder), os.path.join(os.path.dirname(target), folder)]
    mdir = next((os.path.abspath(c) for c in cands if os.path.isdir(c)), None)
    if not mdir:
        rep.say("Папка модуля не найдена: " + folder)
        return 2
    files = sorted(os.listdir(mdir))
    mptr = next((f for f in files if f.endswith("_CURRENT_POINTER.json")), None)
    mcore = next((f for f in files if f.endswith("_CORE.json")), None)
    if not mcore:
        rep.say("В папке нет файла *_CORE.json: это не модуль со своим CORE. Подключение отменено.")
        return 2
    d = read_json(os.path.join(mdir, mcore))
    if not isinstance(d, dict) or d.get("document_type") != "CORE":
        rep.say("%s не читается как CORE. Подключение отменено." % mcore)
        return 2
    nm = re.sub(r"[^A-Z0-9]+", "_", (name or os.path.basename(mdir)).upper()).strip("_")
    rep.say("Модуль: %s; папка: %s; CORE: %s (%s); указатель модуля: %s" % (nm, os.path.basename(mdir), mcore, d.get("revision"), mptr or "НЕТ — работай по CORE, указатель создаст мастер модуля"))
    if mptr:
        mp = read_json(os.path.join(mdir, mptr)) or {}
        bad = [(n, r) for n, r in local_vs_manifest(mdir, mp) if r != "OK"]
        for n, r in bad:
            rep.say("  ВНИМАНИЕ %s: %s" % (n, r))
    pc = ptr.setdefault("project_contours", {"contours": {}})
    pc.setdefault("contours", {})
    prev = pc["contours"].get(nm)
    entry = {"status": "CONNECTED", "optional": True, "folder": os.path.basename(mdir), "core": mcore, "pointer": mptr,
             "connected_at": now().isoformat(),
             "flow": "P1AY -> выбранные данные из USER.state_signals -> модуль; модуль -> компактный итог через TEMP -> мастер P1AY. Модуль мастера P1AY не пишет."}
    if dry:
        rep.say("План (ничего не записано): %s: %s -> CONNECTED" % (nm, (prev or {}).get("status", "новый")))
        return 0
    os.makedirs(os.path.join(target, "P1AY_BACKUP"), exist_ok=True)
    shutil.copyfile(pp, os.path.join(target, "P1AY_BACKUP", "P1AY_POINTER_PRE_LINK_%s.json" % now().strftime("%Y%m%dT%H%M%S")))
    pc["contours"][nm] = entry
    ptr["updated_at"] = now().isoformat()
    write_text(pp, dumps(ptr, True))
    chk = read_json(pp)
    ok = bool(chk and chk["project_contours"]["contours"].get(nm, {}).get("status") == "CONNECTED")
    rep.say("Записано в указатель, перечитано: " + ("OK" if ok else "СБОЙ"))
    rep.say("Дальше: данные, которые P1AY уже собрал (PULSE, сон, screen time, LIFE HOURS, контекст), мастер передаёт модулю при первой сессии: источники, даты и пометки сохраняются, пустое остаётся UNKNOWN.")
    return 0 if ok else 1


def make_sync(master):
    return {"transport": "GOOGLE_DRIVE", "drive_folder": "My Drive/P1AY",
            "master": master,
            "devices_and_other_clients": "CLIENT: read, verify, deliver TEMP only",
            "rules": SYNC_RULES, "updated_at": now().isoformat()}


def master_name(ptr):
    return (((ptr or {}).get("sync") or {}).get("master") or {}).get("name") or "Claude"


def sync_status(target, rep, strict=False):
    ptr = read_json(os.path.join(target, "P1AY_CURRENT_POINTER.json"))
    rep.head("СИНХРОНИЗАЦИЯ GOOGLE DRIVE")
    problems = 0
    rep.say("Основной мастер: %s — единственный писатель мастеров (выбран при установке)." % master_name(ptr))
    rep.say("Это устройство (%s): КЛИЕНТ — читает, проверяет, кладёт файлы в TEMP." % device_name())
    di = drive_info(target)
    rep.say("Папка внутри Google Drive: " + ("да" if di["inside_drive"] else "НЕТ — синхронизации между устройствами не будет"))
    problems += 0 if di["inside_drive"] else 1
    if not ptr:
        rep.say("Указатель не найден: система не установлена в этой папке.")
        return 2
    rep.say("Мастера локально и указатель:")
    for n, r in local_vs_manifest(target, ptr):
        rep.say("  %-28s %s" % (n, r))
        problems += 0 if r == "OK" else 1
    conf = drive_conflicts(target)
    if conf:
        problems += len(conf)
        rep.say("Конфликтные копии Drive (не сливать молча):")
        for c in conf:
            rep.say("  - " + c)
    else:
        rep.say("Конфликтных копий Drive нет.")
    tdir = os.path.join(target, "TEMP")
    names = [f for f in sorted(os.listdir(tdir)) if f not in JUNK and not f.startswith("._")] if os.path.isdir(tdir) else []
    rep.say("Очередь TEMP: %d файлов (применяет мастер: %s)" % (len(names), master_name(ptr)))
    for f in names[:20]:
        rep.say("  - " + f)
    cont = ((ptr or {}).get("project_contours") or {}).get("contours") or {}
    if cont:
        rep.say("Модули и контуры (подключаются позже; данные для них P1AY собирает сам):")
        for n, v in cont.items():
            rep.say("  %-18s %s" % (n, (v or {}).get("status", "?")))
    if problems:
        rep.say("Если файлы «отличаются» или «нет файла» — скорее всего Drive ещё не докачал: подожди и повтори. Править мастера на клиенте нельзя.")
    rep.say("Итог: " + ("всё в порядке" if not problems else "есть вопросы (%d)" % problems))
    return 1 if (strict and problems) else 0


def sync_deliver(target, file, rep, name=None):
    if not os.path.isfile(file):
        rep.say("Нет файла: " + file)
        return 2
    os.makedirs(os.path.join(target, "TEMP"), exist_ok=True)
    fn = "TEMP_%s_%s_%s" % (device_name(name), now().strftime("%Y%m%dT%H%M%S"), os.path.basename(file))
    shutil.copyfile(file, os.path.join(target, "TEMP", fn))
    rep.say("Положено в TEMP/%s. Мастера не менялись: применяет их основной мастер (%s)." % (fn, master_name(read_json(os.path.join(target, "P1AY_CURRENT_POINTER.json")))))
    return 0



def build_pointer(target, uids, lang, manifest, first_run, old_ptr, sync=None):
    ts = now().isoformat()
    _folder = os.path.basename(os.path.normpath(target)) or "P1AY"
    _lp = lambda rel: _folder + "/" + rel.replace(os.sep, "/")
    ptr = {
        "schema": "P1AY_CANONICAL_POINTER_01",
        "first_command": "FIRST COMMAND: OPEN BY PATH, NEVER SEARCH. Open the masters by path and name as listed in load_by_path, by listing the folder. Do not search by name and do not decide what to load by Drive ID or revision number. 'Not found' from a search is a search error, not a missing file: list the folder and read again.",
        "decision": VERSION + ": JSON masters; COMMUNICATION = style, CONTEXT = correspondence and sources",
        "status": "ACTIVE", "owner": uids[0] if uids else None,
        "canonical_files": {
            "core": {"name": "P1AY_CORE.json", "language": "en", "role": "CORE_BASE_SOLE_MASTER"},
            "users": [{"name": "P1AY_%s.json" % u, "role": "USER_FILE", "owner_id": u, "schema": USER_SCHEMA} for u in uids],
            "communication": {"name": "P1AY_COMMUNICATION.json", "role": "COMMUNICATION_STYLE"},
            "context": {"name": "P1AY_CONTEXT_<NNN>.json", "role": "CONTEXT", "load": "on_demand",
                        "parts": [m for m in manifest if m["role"] == "CONTEXT"]},
            "projects": [],
            "project_note": "projects: [] does not mean no project contours exist; authority is resolved from the actual project folder and its CORE (D23).",
        },
        "rules": POINTER_RULES,
        "load_order": ["P1AY_CORE.json"] + (["P1AY_CORE_%s.json" % lang.upper()] if lang != "en" else []) +
                      ["P1AY_<USER_ID>.json", "P1AY_COMMUNICATION.json",
                       "<PROJECT_FOLDER>/CORE and its present layers (when the task is about a project)",
                       "P1AY_CONTEXT_<NNN>.json (on demand)"],
        "updated_at": ts, "master_writer": ((sync or {}).get("master") or {}).get("name", "Claude"), "other_clients": "TEMP only -> TEMP/",
        "build": VERSION, "build_status": "INSTALLED_FROM_RELEASE",
        "revisions": {m["role"].lower(): m["revision"] for m in manifest if m["role"] not in ("CONTEXT", "CORE_PART")},
        "master_manifest": manifest, "first_run": first_run, "sync": sync,
        "execution_protocol": {"rule_id": "CORE.CONFORMANCE.GATE.001", "required": True,
                               "formula": "CORE PREFLIGHT -> TASK -> CORE POSTFLIGHT -> WRITE-CONVERGENCE -> OUTPUT",
                               "rule_number_one": "Always look in CORE.",
                               "pre_task": "Resolve current pointer; load/apply CORE load=always kernel and language layer before task data or action; scoped rules on demand.",
                               "pre_output": "Check prepared answer/action/artifact/status against current CORE and language rules immediately before delivery; correct violations or state a relevant blocker.",
                               "user_confirmation_required": False},
    }
    ptr["canonical_files"]["core_parts"] = [{"name": m["name"], "path": m["path"], "role": "CORE_ON_DEMAND_PART", "load": "on_demand"}
                                            for m in manifest if m["role"] == "CORE_PART"]
    ptr["load_by_path"] = {
        "rule": "Load by PATH and name. Drive IDs are fallback only; revisions and hashes are informational (master_manifest).",
        "order": [_lp(m["path"]) for m in manifest if m["role"] not in ("CONTEXT", "CORE_PART")],
        "on_demand": [_lp(m["path"]) for m in manifest if m["role"] in ("CORE_PART", "CONTEXT")],
        "pointer": _lp("P1AY_CURRENT_POINTER.json")}
    if lang != "en":
        ptr["canonical_files"]["core_" + lang] = {"name": "P1AY_CORE_%s.json" % lang.upper(), "language": lang,
                                                  "role": "CORE_LANGUAGE_LAYER", "extends": "P1AY_CORE.json"}
    _a = os.path.join(target, "P1AY_ONBOARDING.html")
    if os.path.isfile(_a):
        ptr["design_assets"] = {"onboarding": {"name": "P1AY_ONBOARDING.html", "role": "ONBOARDING_DESIGN_REFERENCE",
                                               "bytes": os.path.getsize(_a), "sha256": sha_file(_a),
                                               "spec": "CORE runtime_protocol[4] FIRST RESPONSE; CORE wins on any difference",
                                               "note": "Образец для показа: кнопки без действий; не мастер и не источник правил."}}
    if old_ptr and old_ptr.get("project_contours"):
        ptr["project_contours"] = old_ptr["project_contours"]
    else:
        ptr["project_contours"] = {
            "rule": "Authority per module/project = its own pointer + manifest. P1AY collects the base data natively and works without modules (CORE MODULES.LINK.001). Connect later with: python3 P1AY_FIRST_RUN.py --target <папка P1AY> --link-module <папка модуля>",
            "contours": {n: {"status": "NOT_CONNECTED", "optional": True} for n in ("STATE_NAVIGATOR", "DIGITAL_TWIN")}}
    ptr["revisions"]["context"] = max([m["revision"] for m in manifest if m["role"] == "CONTEXT"] or ["r0"], key=rev_num)
    return ptr


def manifest_entry(target, rel, role):
    p = os.path.join(target, rel)
    d = read_json(p) or {}
    return {"name": os.path.basename(rel), "path": rel.replace(os.sep, "/"), "role": role,
            "revision": d.get("revision"), "bytes": os.path.getsize(p), "sha256": sha_file(p)}


def verify(target, ptr, rep):
    ok = True
    prev_end = None
    for m in ptr["master_manifest"]:
        p = os.path.join(target, m["path"])
        d = read_json(p) if os.path.isfile(p) else None
        good = d is not None and sha_file(p) == m["sha256"] and os.path.getsize(p) == m["bytes"] and d.get("revision") == m["revision"]
        ok &= good
        rep.say("  %-5s %-28s %-4s %9d байт  sha256 %s" % ("OK" if good else "СБОЙ", m["name"], m["revision"], m["bytes"], m["sha256"][:12]))
    ctx = sorted([m for m in ptr["master_manifest"] if m["role"] == "CONTEXT"], key=lambda m: m["name"])
    for m in ctx:
        d = read_json(os.path.join(target, m["path"])) or {}
        if prev_end is not None and d.get("record_start") != prev_end:
            ok = False
            rep.say("  СБОЙ  CONTEXT: разрыв номеров записей перед " + m["name"])
        prev_end = d.get("record_end_exclusive")
    for n in ptr["load_order"]:
        if n.startswith("P1AY_CORE") and not os.path.isfile(os.path.join(target, n)):
            ok = False
            rep.say("  СБОЙ  из load_order нет файла " + n)
    core = read_json(os.path.join(target, "P1AY_CORE.json")) or {}
    for sec in (core.get("load_tiers") or {}).get("on_demand", []):
        fn = sec.split(" ")[0]
        if fn.startswith("CONTEXT/P1AY_CORE_") and "<" not in fn and not os.path.isfile(os.path.join(target, fn)):
            ok = False
            rep.say("  СБОЙ  нет части CORE: " + fn + " (ядро ссылается на неё)")
    return ok


def rollback(target, backup, pre_files, arch, rep):
    """Вернуть папку к состоянию до запуска: файлы из Archive назад, мастера из бэкапа, новые файлы убрать."""
    adir = arch.finalize()
    if adir:
        for it in arch.items:
            cur = os.path.join(target, it["from"])
            if os.path.isfile(cur):
                os.remove(cur)
        do_restore(target, adir, rep)
    if backup and os.path.isfile(backup):
        with zipfile.ZipFile(backup) as z:
            for n in z.namelist():
                if n == "MANIFEST.json":
                    continue
                dst = os.path.join(target, n)
                os.makedirs(os.path.dirname(dst) or target, exist_ok=True)
                with open(dst, "wb") as f:
                    f.write(z.read(n))
    for r, _, fs in os.walk(target):
        for f in fs:
            rel = os.path.relpath(os.path.join(r, f), target)
            if rel not in pre_files and not rel.startswith("P1AY_BACKUP") and not rel.startswith("Archive"):
                os.remove(os.path.join(r, f))


def do_restore(target, batch, rep):
    d = batch if os.path.isabs(batch) else os.path.join(target, "Archive", os.path.basename(batch))
    man = read_json(os.path.join(d, "ARCHIVE_MANIFEST.json"))
    if not man:
        rep.say("Не найден ARCHIVE_MANIFEST.json в " + d)
        return 2
    n = 0
    for it in man["items"]:
        src, dst = os.path.join(target, it["to"]), os.path.join(target, it["from"])
        if os.path.exists(dst):
            rep.say("пропущен (место занято): " + it["from"])
            continue
        if os.path.isfile(src):
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.move(src, dst)
            n += 1
    rep.say("Возвращено файлов: %d из %d" % (n, len(man["items"])))
    return 0


def print_screen(target, n, lang):
    """Лёгкий HTML одного экрана онбординга (~7 КБ вместо 42 КБ): ИИ печатает в чат только его."""
    import re
    src = None
    for p in (os.path.join(target, "P1AY_ONBOARDING.html"), os.path.join(HERE, "system", "P1AY_ONBOARDING.html"), os.path.join(HERE, "P1AY_ONBOARDING.html")):
        if os.path.isfile(p):
            src = p
            break
    if not src:
        print("P1AY_ONBOARDING.html не найден", file=sys.stderr)
        return 1
    t = open(src, encoding="utf-8").read()
    lang = "ru" if lang == "ru" else "en"
    m = re.search(r'<div class="row" data-l="%s">(.*?)(?=<div class="row" data-l=|<div id="lg")' % lang, t, re.S)
    secs = re.findall(r'<section class="f">(.*?)</section>', m.group(1), re.S)
    body = re.sub(r'<div class="c">.*?</div>', "", secs[n - 1], count=1, flags=re.S)
    say = {"ru": ("Напиши в чат: «%s»", "Страница сама ничего не отправляет: ответь в чате."), "en": ("Write in the chat: “%s”", "This page sends nothing itself: answer in the chat.")}[lang]
    css = ("body{margin:0;padding:12px;background:#EDEFFA;display:flex;justify-content:center;font-family:Onest,sans-serif;color:#1A1F3D}"
           ".s{width:390px;max-width:100%;border-radius:28px;overflow:hidden;box-shadow:0 10px 30px rgba(40,40,90,.15)}"
           ".tri{display:inline-block;font-size:.88em;line-height:1;position:relative;top:-.05em;margin:0 -.05em}"
           ".s button{transition:transform .12s}.s button:active{transform:scale(.98)}.s button.pick{outline:2px solid #6554D9;outline-offset:2px}"
           "#chip{display:none;margin:10px auto 0;width:366px;max-width:100%;box-sizing:border-box;padding:12px 14px;border-radius:16px;background:#fff;box-shadow:0 6px 24px rgba(26,31,61,.22);font:500 14px/1.35 Onest,sans-serif}"
           "#chip small{display:block;margin-top:6px;color:#4B5578;font-size:12px}")
    js = ('var T=%s,c=document.getElementById("chip");document.querySelectorAll(".s button").forEach(function(b){b.addEventListener("click",function(){'
          'document.querySelectorAll(".s button").forEach(function(x){x.classList.remove("pick")});b.classList.add("pick");'
          'var q=b.textContent.replace(/\\s+/g," ").trim();c.innerHTML="";var p=document.createElement("div");p.textContent=T[0].replace("%%s",q);c.appendChild(p);'
          'var h=document.createElement("small");h.textContent=T[1];c.appendChild(h);c.style.display="block"})})') % json.dumps(list(say), ensure_ascii=False)
    out = ('<!doctype html><html lang="%s"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>P1AY</title>'
           '<link href="https://fonts.googleapis.com/css2?family=Onest:wght@400;600;700;800&display=swap" rel="stylesheet"><style>%s</style></head>'
           '<body><div>%s<div id="chip"></div></div><script>%s</script></body></html>') % (lang, css, body.strip(), js)
    sys.stdout.reconfigure(encoding="utf-8")
    print(out)
    return 0


def main():
    ap = argparse.ArgumentParser(description=VERSION)
    ap.add_argument("--target", help="папка P1AY (по умолчанию - рядом с этим файлом)")
    ap.add_argument("--user-id", help="ID пользователя для чистой установки")
    ap.add_argument("--lang", default="en", help="язык: ru или en (по умолчанию en)")
    ap.add_argument("--archive", action="store_true", help="сразу перенести старые файлы в Archive без вопроса")
    ap.add_argument("--no-archive", action="store_true", help="не предлагать перенос в Archive")
    ap.add_argument("--dry-run", action="store_true", help="только показать план")
    ap.add_argument("--restore", metavar="ПАКЕТ", help="вернуть файлы пакета Archive на место")
    ap.add_argument("--sync-status", action="store_true", help="состояние синхронизации Google Drive")
    ap.add_argument("--sync-check", action="store_true", help="как --sync-status, но код выхода 1 при проблемах")
    ap.add_argument("--deliver", metavar="ФАЙЛ", help="положить файл в TEMP для мастера")
    ap.add_argument("--device-name", help="имя этого устройства")
    ap.add_argument("--master", help="AI-мастер при установке (по умолчанию Claude)")
    ap.add_argument("--link-module", metavar="ПАПКА", help="подключить модуль (контур) к указателю")
    ap.add_argument("--module", help="имя модуля для --link-module")
    ap.add_argument("--screen", type=int, choices=[1,2,3,4], help="напечатать лёгкий HTML одного экрана онбординга (на языке --lang), чтобы показать его в чате")
    ap.add_argument("--zip-out", metavar="ФАЙЛ", help="после установки упаковать результат (папку P1AY) в один zip - для ИИ в песочнице без доступа к диску")
    a = ap.parse_args()
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    if a.screen:
        return print_screen(os.path.abspath(a.target or HERE), a.screen, a.lang)
    rep = Report()
    target = os.path.abspath(a.target or HERE)
    t0 = now()
    ts = t0.strftime("%Y%m%dT%H%M%S")
    rep.say("=" * 64)
    rep.say(VERSION + " — первый запуск")
    rep.say("Папка: " + target)
    rep.say("Время: " + t0.isoformat())
    rep.say("=" * 64)
    if a.restore:
        return do_restore(target, a.restore, rep)
    if a.sync_status or a.sync_check:
        return sync_status(target, rep, strict=a.sync_check)
    if a.deliver:
        return sync_deliver(target, a.deliver, rep, a.device_name)
    if a.link_module:
        return link_module(target, a.link_module, rep, a.module, a.dry_run)
    if a.lang not in ("ru", "en"):
        rep.say("В релизе есть языковой слой только ru; для других языков используй --lang en (базовый CORE английский).")
        return 2
    pkg = verify_package(rep)
    if not pkg:
        return 2
    os.makedirs(target, exist_ok=True)
    if not os.access(target, os.W_OK):
        rep.say("ОШИБКА: нет прав записи в " + target)
        return 2
    st = scan(target)
    has_old = bool(st["core"] or st["lang"] or st["user"] or st["user_old"] or st["comm"] or st["comm_old"]
                   or st["context"] or st["pointer"] or st["legacy"])
    complete = bool(st["core"] and st["comm"] and st["user"] and st["context"])
    clean_old = not (st["legacy"] or st["user_old"] or st["comm_old"])
    comm_outdated = False
    if st["comm"]:
        _c = read_json(os.path.join(target, st["comm"][0])) or {}
        comm_outdated = any(r.get("id") == "COMM.BRIEF" and r.get("text") in OLD_COMM_BRIEF for r in _c.get("base_rules", []))
    mode = "ЧИСТАЯ УСТАНОВКА" if not has_old else ("ПРОВЕРКА уже установленной системы" if complete and clean_old and not comm_outdated else "ОБНОВЛЕНИЕ существующей системы")
    rep.say("Режим: " + mode)
    rep.say("Найдено: мастера %d, старые версии мастеров %d, другие старые файлы %d, очередь TEMP %d" % (
        sum(1 for k in ("core", "comm") if st[k]) + len(st["lang"]) + len(st["user"]) + len(st["context"]),
        len(st["user_old"]) + (1 if st["comm_old"] else 0), len(st["legacy"]), len(st["temp"])))
    old_ptr = read_json(os.path.join(target, st["pointer"])) if st["pointer"] else None
    known = dict((old_ptr or {}).get("first_run", {}).get("imported", {}))
    master = ((old_ptr or {}).get("sync") or {}).get("master")
    if master:
        master.setdefault("name", str(master.get("id") or "Claude").title())
        master.pop("fixed", None)
        rep.say("Мастер уже определён: %s (сохранён без вопроса)." % master.get("name"))
    else:
        mname = a.master or ("Claude" if a.dry_run else ask("Какой AI будет мастером (единственным писателем файлов)? [Claude]: ", "Claude"))
        mname = re.sub(r"\s+", " ", mname).strip()[:40] or "Claude"
        master = {"id": re.sub(r"[^A-Z0-9_]+", "_", mname.upper()), "name": mname, "kind": "AI_MASTER_WRITER",
                  "chosen_by": "owner", "chosen_at": now().isoformat()}
        rep.say("Мастер выбран при установке: %s" % mname)

    # пользователь
    uids = sorted(m[1]["owner_id"] or fn[5:-5] for fn, m in st["user"].items())
    need_new_user = not uids
    uid = None
    if need_new_user:
        uid = a.user_id or detect_user_id(st)
        if not a.user_id:
            uid = uid or new_local_id()
            uid = ask("Локальный ключ файла (латиница/цифры; это не личность, глобальный user_id остаётся UNKNOWN) [%s]: " % uid, uid)
        uid = uid or new_local_id()
        if not re.fullmatch(r"[A-Za-z0-9_]{2,32}", uid):
            rep.say("ОШИБКА: ID должен быть из латиницы, цифр и _ (2-32 символа)")
            return 2
        uids = [uid]
    for fn, (rel, meta) in st["user_old"].items():
        o = meta["owner_id"] or fn[5:-5]
        if o not in uids and not need_new_user:
            uids.append(o)

    if a.dry_run:
        rep.head("ПЛАН (ничего не записано)")
        rep.say("Бэкап: " + ("да" if has_old else "не нужен"))
        rep.say("USER: " + ", ".join(uids) + (" (новый)" if need_new_user else ""))
        rep.say("К переносу в CONTEXT: %d файлов; TEMP в очереди: %d" % (len(st["legacy"]), len(st["temp"])))
        return 0

    pre_files = set(os.path.relpath(os.path.join(r, f), target) for r, _, fs in os.walk(target) for f in fs)
    arch = Archive(target, ts)
    lang = a.lang
    # 1. бэкап
    rep.head("1. Бэкап")
    backup = None
    if has_old:
        keep = [x[0] for x in ([st["core"]] if st["core"] else [])] + [v[0] for v in st["lang"].values()] + \
               [v[0] for v in st["user"].values()] + [v[0] for v in st["user_old"].values()] + \
               ([st["comm"][0]] if st["comm"] else []) + ([st["comm_old"][0]] if st["comm_old"] else []) + \
               [r for r, _ in st["context"]] + ([st["pointer"]] if st["pointer"] else []) + \
               [v[0] for v in st["core_parts"].values()]
        os.makedirs(os.path.join(target, "P1AY_BACKUP"), exist_ok=True)
        backup = os.path.join(target, "P1AY_BACKUP", "P1AY_BACKUP_%s_PRE_FIRST_RUN.zip" % t0.strftime("%Y-%m-%d_%H%M"))
        man = {"created_at": t0.isoformat(), "by": VERSION, "files": []}
        with zipfile.ZipFile(backup, "w", zipfile.ZIP_DEFLATED) as z:
            for rel in keep:
                z.write(os.path.join(target, rel), rel)
                man["files"].append({"name": rel, "sha256": sha_file(os.path.join(target, rel))})
            z.writestr("MANIFEST.json", dumps(man))
        with zipfile.ZipFile(backup) as z:
            assert z.testzip() is None
        rep.say("Бэкап: %s (%d файлов, проверен)" % (os.path.relpath(backup, target), len(keep)))
    else:
        rep.say("Пока нечего сохранять (чистая установка).")
    for d in ("CONTEXT", "TEMP", "P1AY_BACKUP"):
        os.makedirs(os.path.join(target, d), exist_ok=True)

    # 2. CORE и язык
    rep.head("2. CORE и языковой слой")
    def install(name, cur):
        src = os.path.join(PKG, name)
        dst = os.path.join(target, name)
        prev = (read_json(src) or {}).get("revision")
        if cur is not None:
            crel, cmeta = cur
            if rev_num(cmeta["revision"]) > rev_num(prev):
                rep.say("  %s: оставлен установленный %s (новее релизного %s)" % (name, cmeta["revision"], prev)); return
            if rev_num(cmeta["revision"]) == rev_num(prev) and sha_file(os.path.join(target, crel)) == sha_file(src):
                rep.say("  %s: уже актуален (%s)" % (name, prev)); return
            if rev_num(cmeta["revision"]) == rev_num(prev):
                rep.say("  ВНИМАНИЕ %s: та же ревизия %s, но содержимое отличается — оставлен установленный" % (name, prev)); return
            arch.move(crel, "заменён релизным %s" % name)
            rep.say("  %s: обновлён %s -> %s (старый в Archive)" % (name, cmeta["revision"], prev))
        else:
            if os.path.exists(dst):
                arch.move(name, "старый файл с тем же именем")
            rep.say("  %s: установлен %s" % (name, prev))
        shutil.copyfile(src, dst)
    install("P1AY_CORE.json", st["core"])
    if lang != "en":
        lname = "P1AY_CORE_%s.json" % lang.upper()
        install(lname, st["lang"].get(lname))
    # 2a. части CORE по запросу (полные тексты правил, журнал решений) -> CONTEXT/
    _pdir = os.path.join(PKG, "CONTEXT")
    for _pn in (sorted(os.listdir(_pdir)) if os.path.isdir(_pdir) else []):
        _m = CORE_PART_RE.match(_pn)
        if not _m:
            continue
        if _m.group(1) and _m.group(1)[1:].lower() != lang:
            continue
        install(os.path.join("CONTEXT", _pn), st["core_parts"].get(_pn))
    if not os.path.isdir(_pdir):
        # релиз с единым CORE: прежние файлы полных текстов правил больше не нужны, уходят в Archive (не удаляются)
        for _pn, (_prel, _pm) in sorted(st["core_parts"].items()):
            if "_RULES_" in _pn:
                arch.move(_prel, "CORE теперь один файл; прежние тексты правил перенесены в Archive")
                rep.say("  %s: перенесён в Archive (CORE теперь один файл)" % _prel)

    _asset = os.path.join(PKG, "P1AY_ONBOARDING.html")
    _onb_done = False
    for _fn, (_rel, _m) in st["user"].items():
        _ud = read_json(os.path.join(target, _rel)) or {}
        if any(i.get("id") == "ONBOARDING.START" and i.get("status") == "DONE" for i in _ud.get("open_items", [])):
            _onb_done = True
    if _onb_done:
        rep.say("  P1AY_ONBOARDING.html: не ставится (онбординг пройден, ONBOARDING.START = DONE)")
    elif os.path.isfile(_asset):
        _dst = os.path.join(target, "P1AY_ONBOARDING.html")
        if not os.path.exists(_dst):
            shutil.copyfile(_asset, _dst)
            rep.say("  P1AY_ONBOARDING.html: установлен (готовый дизайн онбординга, образец для показа)")
        elif sha_file(_dst) != sha_file(_asset):
            arch.move("P1AY_ONBOARDING.html", "заменён релизным образцом дизайна")
            shutil.copyfile(_asset, _dst)
            rep.say("  P1AY_ONBOARDING.html: обновлён (старый в Archive)")
        else:
            rep.say("  P1AY_ONBOARDING.html: уже актуален")

    # 2b. набор дашбордов (универсальные виды): ставится только если сборщика ещё нет
    _kit = os.path.join(PKG, "dashboard", "build")
    if os.path.isdir(_kit):
        _kdst = os.path.join(target, "P1AY_DASHBOARD", "build")
        if os.path.isdir(_kdst):
            rep.say("  P1AY_DASHBOARD/build: уже есть, не тронут")
        else:
            shutil.copytree(_kit, _kdst, ignore=shutil.ignore_patterns("__pycache__"))
            rep.say("  P1AY_DASHBOARD/build: установлен набор дашбордов (Пульс, Карты, Сезон; язык из USER.language). Сборка: cd P1AY_DASHBOARD && python3 build/build.py --queue-temp ../TEMP")

    # 3. история аккаунта -> CONTEXT
    rep.head("3. История и CONTEXT")
    import_list = list(st["legacy"])
    replaced = []
    for fn, (rel, meta) in st["user_old"].items():
        replaced.append(rel)
    if st["comm_old"]:
        replaced.append(st["comm_old"][0])
    import_list += replaced
    tmpl_ctx = read_json(os.path.join(PKG, "templates", "CONTEXT.json"))
    existing = [(r, m) for r, m in st["context"]]
    next_idx = max([m["end"] or 0 for _, m in existing] or [0])
    recs, imported = import_sources(target, import_list, known, next_idx, t0.isoformat())
    new_parts = []
    if recs or not existing:
        new_parts = write_context_parts(target, tmpl_ctx, existing, recs, uids[0], t0.isoformat(), a.lang)
    if existing and not recs:
        rep.say("  CONTEXT: существующие части сохранены без изменений (%d)" % len(existing))
    if recs:
        rep.say("  История перенесена в CONTEXT: %d файлов (текст без потерь, sha256 сохранены)" % len(recs))
    elif not existing:
        rep.say("  Первая установка: CONTEXT создан пустым, история начнётся с первой сессии.")

    # 4. USER и COMMUNICATION
    rep.head("4. USER и COMMUNICATION")
    layers = ["P1AY_CORE.json"] + (["P1AY_CORE_%s.json" % lang.upper()] if lang != "en" else [])
    for fn, (rel, meta) in list(st["user_old"].items()):
        arch.move(rel, "старая схема USER; содержимое перенесено в CONTEXT", imported.get(rel))
    uid_now = now()
    made_users = list(uids) if need_new_user else [u for u in uids if ("P1AY_%s.json" % u) not in st["user"]]
    for u in uids:
        path = os.path.join(target, "P1AY_%s.json" % u)
        if os.path.exists(path):
            rep.say("  P1AY_%s.json: существует (схема 02), оставлен" % u)
            continue
        t = read_json(os.path.join(PKG, "templates", "USER.json"))
        t.update({"name": "P1AY_" + u, "owner_id": u, "language": lang, "date": uid_now.strftime("%Y-%m-%d"),
                  "timezone": uid_now.strftime("%z")[:3] + ":" + uid_now.strftime("%z")[3:], "core_layers": layers,
                  "revision": "r1", "status": "ACTIVE", "updated_at": uid_now.isoformat()})
        t["profile"]["identity"]["canonical_id"] = u
        t["profile"]["identity"]["local_profile_id"] = u
        t["profile"]["identity"]["user_id"] = "UNKNOWN"
        if lang == "en":
            for o in t["open_items"]:
                if o.get("id") == "ONBOARDING.START":
                    o["text"] = "Onboarding not completed. In the first session the assistant follows CORE (WAY_6BG_3MAIN_001) to choose directions and create the starting task structure; the person answers, nothing is invented. Then status -> DONE."
        if not any(o.get("id") == "ONBOARDING.START" for o in t["open_items"]):
            t["open_items"].insert(0, {"id": "ONBOARDING.START", "status": "PENDING", "text": "Онбординг не пройден: при первой сессии провести по CORE (WAY_6BG_3MAIN_001), ничего не выдумывать."})
        if imported:
            t["open_items"].append({"id": "FIRST_FILL", "status": "PENDING",
                "text": "Аккаунт уже существовал. Заполнить профиль, состояние, квесты и людей из CONTEXT (записи %s ... %s). Не выдумывать: только то, что есть в источниках; догадки помечать." % (
                    min(imported.values()), max(imported.values()))})
        write_text(path, dumps(t))
        rep.say("  P1AY_%s.json: создан (шаблон, схема 02)" % u)
    cpath = os.path.join(target, "P1AY_COMMUNICATION.json")
    if st["comm"]:
        _cd = read_json(cpath) or {}
        _tm = read_json(os.path.join(PKG, "templates", "COMMUNICATION.json"))
        _nb = [r for r in _tm.get("base_rules", []) if r.get("id") == "COMM.BRIEF"]
        _chg = False
        for r in _cd.get("base_rules", []):
            if _nb and r.get("id") == "COMM.BRIEF" and r.get("text") in OLD_COMM_BRIEF:
                r["text"] = _nb[0]["text"]; _chg = True
        if _chg:
            _cd["revision"] = "r%d" % (rev_num(_cd.get("revision")) + 1)
            _cd["updated_at"] = uid_now.isoformat()
            write_text(cpath, dumps(_cd))
            rep.say("  P1AY_COMMUNICATION.json: устаревший COMM.BRIEF заменён по шаблону, ревизия %s (прежняя копия в бэкапе)" % _cd["revision"])
        else:
            rep.say("  P1AY_COMMUNICATION.json: существует, оставлен")
    else:
        if st["comm_old"]:
            arch.move(st["comm_old"][0], "старая схема COMMUNICATION; содержимое перенесено в CONTEXT", imported.get(st["comm_old"][0]))
        c = read_json(os.path.join(PKG, "templates", "COMMUNICATION.json"))
        c.update({"owner_id": uids[0], "language": lang, "date": uid_now.strftime("%Y-%m-%d"), "revision": "r1", "updated_at": uid_now.isoformat()})
        write_text(cpath, dumps(c))
        rep.say("  P1AY_COMMUNICATION.json: создан (шаблон)")

    # 5. TEMP
    rep.head("5. Очередь TEMP")
    if st["temp"]:
        rep.say("  В TEMP лежит %d файлов. Скрипт их не применяет и не двигает: правит мастера только главный писатель (Claude)." % len(st["temp"]))
        for f in st["temp"]:
            rep.say("    - " + f)
    else:
        rep.say("  TEMP пуст.")
    os.makedirs(os.path.join(target, "P1AY_BACKUP", "TEMP_PROCESSED"), exist_ok=True)
    rep.say("  Порядок: клиент кладёт файл в TEMP/ -> мастер применяет к мастерам, пишет итог в указатель (temp_merge) -> обработанный файл уходит в P1AY_BACKUP/TEMP_PROCESSED_<дата>/. TEMP после этого пуст.")

    # 6. указатель
    rep.head("6. Указатель и проверка")
    st2 = scan(target)
    manifest = []
    manifest.append(manifest_entry(target, "P1AY_CORE.json", "CORE"))
    if lang != "en":
        manifest.append(manifest_entry(target, "P1AY_CORE_%s.json" % lang.upper(), "CORE_%s" % lang.upper()))
    for fn in sorted(st2["user"]):
        manifest.append(manifest_entry(target, st2["user"][fn][0], "USER"))
    manifest.append(manifest_entry(target, "P1AY_COMMUNICATION.json", "COMMUNICATION"))
    for fn in sorted(st2["core_parts"]):
        manifest.append(manifest_entry(target, st2["core_parts"][fn][0], "CORE_PART"))
    for rel, _ in st2["context"]:
        manifest.append(manifest_entry(target, rel, "CONTEXT"))
    first_run = {"version": VERSION, "ran_at": t0.isoformat(), "mode": mode, "backup": os.path.relpath(backup, target) if backup else None,
                 "imported": known, "temp_pending": st["temp"]}
    ptr = build_pointer(target, sorted(st2["user"]) and [st2["user"][f][1]["owner_id"] or f[5:-5] for f in sorted(st2["user"])] or uids, lang, manifest, first_run, old_ptr, sync=make_sync(master))
    if old_ptr:
        ptr["previous_verification"] = old_ptr.get("verification")
        for k, v in old_ptr.items():
            if k not in ptr and k != "verification":
                ptr[k] = v
    ptr["verification"] = "PENDING: проверка чтением ещё не выполнена"
    write_text(os.path.join(target, "P1AY_CURRENT_POINTER.json"), dumps(ptr, True))
    ok = verify(target, ptr, rep)
    if ok:
        ptr["verification"] = "FIRST_RUN %s: masters read back, sha256 match master_manifest (целостность байтов; содержание не проверялось)" % t0.strftime("%Y-%m-%d")
        write_text(os.path.join(target, "P1AY_CURRENT_POINTER.json"), dumps(ptr, True))
    rep.say("Проверка чтением: " + ("ЦЕЛОСТНОСТЬ БАЙТОВ OK (содержание этим не проверяется)" if ok else "ЕСТЬ СБОИ — система не принята, возвращаю прежнее состояние"))
    if not ok:
        rollback(target, backup, pre_files, arch, rep)
        rep.say("Прежнее состояние восстановлено из бэкапа и Archive; указатель не помечен проверенным.")
        return 3

    # 7. отчёт и архив
    rep.head("ОТЧЁТ")
    rep.say("Версия: " + VERSION)
    rep.say("Режим: " + mode)
    rep.say("Пользователи: " + ", ".join(ptr["owner"] and [u["owner_id"] for u in ptr["canonical_files"]["users"]] or []))
    rep.say("Основной мастер: %s (единственный писатель). Транспорт: Google Drive%s. Это устройство — клиент." % (master["name"],
        "" if drive_info(target)["inside_drive"] else " — ВНИМАНИЕ: папка не внутри Google Drive, между устройствами не синхронизируется"))
    rep.say("Новых частей CONTEXT: %d; перенесено источников: %d" % (len(new_parts), len(recs)))
    rep.say("Файлов Archive уже перемещено при замене старых версий: %d" % len(arch.items))
    candidates = [r for r in st["legacy"] if os.path.exists(os.path.join(target, r))]
    if candidates and ok and not a.no_archive:
        tot = sum(os.path.getsize(os.path.join(target, r)) for r in candidates)
        rep.head("Старые файлы: предложение")
        rep.say("Эти %d файлов (%.1f МБ) теперь не нужны системе; их содержимое уже в CONTEXT или бинарники с sha256:" % (len(candidates), tot / 1e6))
        for r in candidates[:40]:
            rep.say("  - " + r)
        if len(candidates) > 40:
            rep.say("  ... и ещё %d" % (len(candidates) - 40))
        rep.say("Предлагаю ПЕРЕНЕСТИ их в Archive/%s/ (не удалять). Они останутся там до востребования." % arch.batch)
        ans = "да" if a.archive else ask("Перенести в Archive? [да/нет]: ", "нет")
        if is_yes(ans):
            for r in candidates:
                arch.move(r, "старый файл; заменён новой системой", imported.get(r))
            rep.say("Перенесено в Archive: %d файлов. Вернуть: python3 P1AY_FIRST_RUN.py --target \"%s\" --restore %s" % (len(candidates), target, arch.batch))
        else:
            rep.say("Файлы оставлены на месте. Перенести позже: запусти скрипт ещё раз с --archive.")
    adir = arch.finalize()
    if adir:
        rep.say("Манифест архива: " + os.path.relpath(os.path.join(adir, "ARCHIVE_MANIFEST.json"), target))
    rep.head("МИГРАЦИЯ СО СТАРЫХ ВЕРСИЙ")
    if has_old:
        rep.say("Найдена прежняя установка. Перенесено на новую систему: старых версий мастеров %d, прочих старых файлов %d (в CONTEXT записей: %d)." % (
            len(st["user_old"]) + (1 if st["comm_old"] else 0), len(st["legacy"]), len(recs)))
        rep.say("Мастера новее релизных остались как есть; прежние версии CORE/язык заменены, старые копии лежат в Archive/. Бэкап до запуска: " + (os.path.relpath(backup, target) if backup else "нет"))
        rep.say("Откат: --restore <пакет Archive> или файлы из P1AY_BACKUP/.")
    else:
        rep.say("Старых версий нет: чистая установка.")
    onb = []
    for u_ in [x["owner_id"] for x in ptr["canonical_files"]["users"]]:
        d_ = read_json(os.path.join(target, "P1AY_%s.json" % u_)) or {}
        if any(o.get("id") == "ONBOARDING.START" and o.get("status") == "PENDING" for o in d_.get("open_items", [])):
            onb.append(u_)
    if onb:
        rep.head("ОНБОРДИНГ")
        rep.say("Ждут онбординга: " + ", ".join(onb) + ". При первой сессии ассистент проведёт его по CORE (выбор направлений, стартовые задачи). Отвечает человек; ничего не выдумывается.")
    # 2c. дашборд сразу после установки (Пульс = index.html, Карты и Сезон = templates/); без --queue-temp: расписка не нужна на чистой установке
    if not a.dry_run and os.path.isfile(os.path.join(target, "P1AY_DASHBOARD", "build", "build.py")):
        import subprocess
        try:
            r_ = subprocess.run([sys.executable, "build/build.py"], cwd=os.path.join(target, "P1AY_DASHBOARD"), capture_output=True, text=True, timeout=120)
            made = [p_ for p_ in ("index.html",) if os.path.exists(os.path.join(target, "P1AY_DASHBOARD", p_))]
            if r_.returncode == 0 and made:
                rep.head("ДАШБОРДЫ")
                rep.say("Собран дашборд: P1AY_DASHBOARD/index.html. Это витрина, не источник состояния.")
            else:
                rep.say("Дашборды не собрались автоматически: " + (r_.stderr or r_.stdout or "?").strip()[-300:] + " Ручная сборка: cd P1AY_DASHBOARD && python3 build/build.py")
        except Exception as e_:
            rep.say("Дашборды не собрались автоматически (%s). Ручная сборка: cd P1AY_DASHBOARD && python3 build/build.py" % e_)
    sync_status(target, rep)
    rep.head("СИНХРОНИЗАЦИЯ — ОБЯЗАТЕЛЬНО")
    rep.say("1. Папка P1AY должна лежать внутри Google Drive (My Drive/P1AY) и быть одной и той же на всех устройствах.")
    rep.say("2. Писатель мастеров один: %s. Остальные устройства и ИИ — клиенты: читают, проверяют, кладут файлы только в TEMP/." % master["name"])
    rep.say("3. Запись считается только после перечитывания из папки Drive. Сохранение вне Drive — сбой синхронизации, не сохранение.")
    rep.say("4. Если на другом устройстве стоит старая версия: распакуй этот релиз там и запусти этот же скрипт на папке P1AY — база перенесётся.")
    rep.say("5. Проверка в любой момент: python3 P1AY_FIRST_RUN.py --target <папка P1AY> --sync-status")
    rep.say("")
    rep.say("Дальше: загрузи в ассистента P1AY_CURRENT_POINTER.json и файлы из load_order. Новая система общая для всех.")
    write_text(os.path.join(target, "P1AY_FIRST_RUN_REPORT.txt"), "\n".join(rep.lines) + "\n")
    if a.zip_out and not a.dry_run:
        zp = os.path.abspath(a.zip_out)
        skip_dirs = {os.path.basename(HERE)} if os.path.dirname(HERE) == target else set()
        n = 0
        with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
            for root, dirs, files in os.walk(target):
                if root == target:
                    dirs[:] = [d for d in dirs if d not in skip_dirs and d != "P1AY_BACKUP"]
                for fn in files:
                    full = os.path.join(root, fn)
                    if os.path.abspath(full) == zp or fn.startswith("P1AY_VALENTINA_") and fn.endswith(".zip"):
                        continue
                    z.write(full, os.path.join("P1AY", os.path.relpath(full, target)))
                    n += 1
        print("Результат упакован: %s (%d файлов, внутри папка P1AY/)" % (zp, n))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
